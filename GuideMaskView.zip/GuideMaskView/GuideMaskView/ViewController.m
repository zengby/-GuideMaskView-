//
//  ViewController.m
//  GuideMaskView
//
//  Created by zengby on 2017/6/30.
//  Copyright © 2017年 zengby. All rights reserved.
//

#import "ViewController.h"
#import "GuideMaskView.h"
@interface ViewController ()
@property (nonatomic, strong) GuideMaskView *guideMaskView;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    UIButton *buttonOne = [[UIButton alloc]initWithFrame:CGRectMake(100, 100, 40, 50)];
    buttonOne.backgroundColor = [UIColor redColor];
    [buttonOne setTitle:@"按钮" forState:UIControlStateNormal];
    [buttonOne addTarget:self action:@selector(buttonOneAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:buttonOne];
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)buttonOneAction:(UIButton *) button {
    if (!_guideMaskView) {
        CGRect frame = [button convertRect: button.bounds toView:[UIApplication sharedApplication].keyWindow];
        CGRect frameOne = CGRectMake(frame.origin.x - 10, frame.origin.y - 10, frame.size.width + 20, frame.size.height + 20);
        _guideMaskView = [[GuideMaskView alloc]initWithClickFrame:frameOne ifCornerRadius:YES];
        [_guideMaskView guideMaskViewShow];
    }
    else {
        [_guideMaskView guideMaskViewHidden];
        _guideMaskView = nil;
    }
        
}

@end
