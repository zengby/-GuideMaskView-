//
//  AppDelegate.h
//  GuideMaskView
//
//  Created by zengby on 2017/6/30.
//  Copyright © 2017年 zengby. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

