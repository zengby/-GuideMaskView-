//
//  GuideMaskView.m
//  KaiPai
//  引导遮盖
//  Created by zengby on 2017/6/29.
//  Copyright © 2017年 linkxin. All rights reserved.
//

#import "GuideMaskView.h"
#define KWidth  [UIScreen mainScreen].bounds.size.width
#define KHeight  [UIScreen mainScreen].bounds.size.height
@interface GuideMaskView ()
@property (nonatomic, strong) UIView *button;
@end
@implementation GuideMaskView

- (id)initWithClickFrame:(CGRect)frame ifCornerRadius:(BOOL)ifCornerRadius {
    self = [super init];
    if (self) {
        self.frame = CGRectMake(0, 0, KWidth, KHeight);
        self.alpha = 0;
        self.backgroundColor = [UIColor clearColor];
        UIWindow * window = [UIApplication sharedApplication].keyWindow;
        [window addSubview:self];
        _button = [[UIView alloc]initWithFrame:frame];
       
        _button.backgroundColor = [UIColor clearColor];
        [self addSubview:_button];
        
        
        UIBezierPath *path = [UIBezierPath bezierPathWithRect:self.frame];
        // 挖空心洞 显示区域
        UIBezierPath *cutRectPath = [UIBezierPath bezierPathWithRoundedRect:frame cornerRadius:ifCornerRadius ? 10:0];
        //        将circlePath添加到path上
        [path appendPath:cutRectPath];
        path.usesEvenOddFillRule = YES;
        
        CAShapeLayer *fillLayer = [CAShapeLayer layer];
        fillLayer.path = path.CGPath;
        fillLayer.cornerRadius = 10;
        fillLayer.fillRule = kCAFillRuleEvenOdd;
        [fillLayer setFillColor:[UIColor blackColor].CGColor];
        fillLayer.opacity = 0.5;//透明度
        [self.layer addSublayer:fillLayer];
    }
    return self;
}


- (void)guideMaskViewShow {
    [UIView animateWithDuration:0.3 // 动画时长
                          delay:0.0 // 动画延迟
                        options:UIViewAnimationOptionCurveEaseIn // 动画过渡效果
                     animations:^{
                         self.alpha = 1;
                     }
                     completion:^(BOOL finished) {
                         // 动画完成后执行
                         // code...
                     }];
}

- (void)guideMaskViewHidden {
    [self removeFromSuperview];
}

- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    // 拦截点击事件
    CGPoint btnPointInA = [_button convertPoint:point fromView:self];
    if ([_button pointInside:btnPointInA withEvent:event]) {
        return nil;
    }
    // 否则，返回默认处理
    return [super hitTest:point withEvent:event];
    
}

@end
