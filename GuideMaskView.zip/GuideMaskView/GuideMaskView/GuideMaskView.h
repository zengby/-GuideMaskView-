//
//  GuideMaskView.h
//  KaiPai
//  引导遮盖
//  Created by zengby on 2017/6/29.
//  Copyright © 2017年 linkxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GuideMaskView : UIView
/**
 *  创建引导遮盖
 *
 *  @param frame       高亮区域 CGRect
 *  @param ifCornerRadius   高亮区域是否需要圆角
 */
- (id)initWithClickFrame:(CGRect)frame ifCornerRadius:(BOOL)ifCornerRadius;

// 显示
- (void)guideMaskViewShow;

// 隐藏
- (void)guideMaskViewHidden;
@end
